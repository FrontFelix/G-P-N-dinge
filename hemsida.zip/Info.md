*Bilder
Randomisera en mapp där Fredrik själv kan lägga in bilder som direkt uppdateras.


##Footer
Ta bort Google Maps
Lägg till ikoner med länkning.

GVK ( Footer )
Golv Branchen ( Footer )



Ladda ner PDF filer med knapp



GÖ OM HELA NAVBAREN KOLLA UPPGIFT 2


Dropdown på Referenser > Bilder > Sammarbeten
Dropdown på Tjänter > Visa alla tjänster